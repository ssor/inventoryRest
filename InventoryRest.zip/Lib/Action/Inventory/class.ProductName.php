<?php

class ProductName
{
	public $name;
//	public $produceDate;
//	public $productCategory;
//	public $descript;
//	public $state;
	//public function __construct($pName="",$pDate="",$pCategory="",$pDescript="",$pState="")
	public function __construct($pName="")
	{
		$this->name=$pName;
	}
}

?>