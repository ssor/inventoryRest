<?php
/**
* 
*/
class res
{
    public $resID;
    public $time_stamp;
    function __construct($resID = "",$time_stamp = "")
    {
        # code...
        $this->resID = $resID;
        $this->time_stamp = $time_stamp;
    }
}
// http://localhost:9002/index.php/ResSync/resourceSync/get_syc_list
class resourceSyncAction extends Action
{
    /**
    +----------------------------------------------------------
    * 默认操作
    +----------------------------------------------------------
    */
    public function index()
    {
		echo "group1->index";
        //$this->display(THINK_PATH.'/Tpl/Autoindex/hello.html');
    }
    // 获取更新列表，post时间参数，根据上次更新时间获取更新列表
    // 2012-05-09 16:10:24
    public function get_syc_list()
    {
        $jsonInput = file_get_contents("php://input");
        if(empty($jsonInput))
        {
            $sql = "SELECT resID , time_stamp  FROM res_syc order by time_stamp asc;";
        }
        else
        {
            $sql = "SELECT resID , time_stamp  FROM res_syc where time_stamp > '$jsonInput' order by time_stamp asc;";
        }
        $M = new Model();
        $list = $M->query($sql);
        $result = array();
        if (count($list)>0) {
            for($i = 0;$i < count($list);$i++)
            { 
               $res = new res(
                    $list[$i]['resID'],
                    $list[$i]['time_stamp']
                    );  
                array_push($result,$res);
            }               
        }
        
        $foo_json = json_encode($result);
        
        echo $foo_json;
    }
    public function upload_file()
    {

          // var_dump($_FILES);
        // echo $vTime;
        // return;
        import("@.ORG.UploadFile");
        //导入上传类
        $upload = new UploadFile();
        //设置上传文件大小
        $upload->maxSize = 3292200;
        //设置上传文件类型
        $upload->savePath = './Res/';
        $file_name = $_FILES['file']['name'];
        $file = "./Res/".$_FILES['file']['name'];
          // echo $file;
        if(file_exists($file))
        {
          unlink($file);
        }
        // return;
        if (!$upload->upload()) {
            //捕获上传异常
            echo "fail";
        } else 
        {
            //取得成功上传的文件信息
             // $uploadList = $upload->getUploadFileInfo();
             // var_dump($uploadList);
            date_default_timezone_set("Asia/Shanghai");
            $vTime = date("Y-m-d H:i:s");
            $M = new Model();
            $sql_select = "SELECT resID , time_stamp  FROM res_syc where resID = '$resID';";
            $list = $M->query($sql_select);
            if(count($list)<=0)
            {
                $sql = "insert into res_syc(resID , time_stamp) values('$file_name','$vTime');";
            }
            else
            {
                $sql = "update res_syc set time_stamp = '$vTime' where resID = '$resID';";
            }
            $M = new Model();
            $r = $M->execute($sql);
            if ($r) {
                echo "ok";
            }
            else
            {
                echo "fail2";
            }
            // echo "fail22";
        }
    }
    public function download_file()
    {
        $file_name = $_GET['resID'];
        
        $file_path = "./Res/".$file_name;
        //echo "fail";
        //return;
        if(!empty($file_path) and !is_null($file_path))
        {
            //$filename = basename($path);
            $file=@fopen($file_path,"r");
            if($file)
            {
                header("Content-type:application/octet-stream");
                header("Accept-ranges:bytes");
                header("Accept-length:".filesize($file_path));
                header("Content-Disposition:attachment;filename=".$fileNameSystemBased);
                echo fread($file,filesize($file_path));
                fclose($file);
                //echo "ok";
                exit;
            }
        }
        echo "fail";
    }
    /**
    +----------------------------------------------------------
    * 探针模式
    +----------------------------------------------------------
    */
    public function checkEnv()
    {
        load('pointer',THINK_PATH.'/Tpl/Autoindex');//载入探针函数
        $env_table = check_env();//根据当前函数获取当前环境
        echo $env_table;
    }

}
?>