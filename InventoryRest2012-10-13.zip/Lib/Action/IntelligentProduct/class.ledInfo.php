<?php

class ledInfo
{
	public $Tem;
	public $Wet;
	
	public function __construct($_Tem="",$_Wet="")
	{
		$this->Tem=$_Tem;
		$this->Wet=$_Wet;
		
	}
}

?>