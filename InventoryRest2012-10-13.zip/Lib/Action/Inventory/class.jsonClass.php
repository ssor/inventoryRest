<?php

class jsonClass
{
	public $name;
	public $age;
	public function __construct($strname="",$strage="")
	{
		$this->name=$strname;
		$this->age=$strage;
	}
}

?>